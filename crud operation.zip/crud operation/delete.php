<?php
mysql_connect("localhost","root","");
mysql_select_db(crudoperation);

$id = $_GET['ids'];
$deletequery = "delete from user where id=$id";
$query = mysql_query($deletequery);

if($query){
    header('location:select.php');
  }
  else{
    echo "<script> alert('data not deleted');</script>";
  }



?>