<?php
mysql_connect("localhost","root","");
mysql_select_db(crudoperation);
if(isset($_POST['submit'])){
  $name = $_POST['name'];
  $email = $_POST['email'];
  $phone = $_POST['phone'];
  $city = $_POST['city'];
  $password = $_POST['password'];
  $result = "insert into user (name, email, phone, city, password)values('$name', '$email', '$phone', '$city', '$password')";
  if(mysql_query($result)){
    echo "<script> alert('data inserted successfully');</script>";
  }
  else{
    echo "<script> alert('data not inserted');</script>";
  }

}
?>
<!DOCTYPE html>
<!-- Created By CodingLab - www.codinglabweb.com -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <!---<title> Responsive Registration Form | CodingLab </title>--->
    <link rel="stylesheet" href="style.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="container">
    <div class="title">Registration</div>
    <div class="content">
      <form action="" method="post" autocomplete="off">
        <div class="user-details">
          <div class="input-box">
            <span class="details">Full Name</span>
            <input type="text" name="name" placeholder="Enter your name *"  autocomplete="off">
          </div>
         
          <div class="input-box">
            <span class="details">Email</span>
            <input type="text" name="email" placeholder="Enter your email *">
          </div>
          <div class="input-box">
            <span class="details">Phone Number</span>
            <input type="text" name="phone" placeholder="Enter your number *" >
          </div>
          <div class="input-box">
            <span class="details">City</span>
            <select name="city">
              <option value="Agra">Agra</option>
              <option value="Allahabad">Allahabad</option>
              <option value="Banaras">Banaras</option>
              <option value="Gajipur">Gajipur</option>
              <option value="Gorakhpur">Gorakhpur</option>
              <option value="Kanpur">Kanpur</option>
              <option value="Kushinagar">Kushinagar</option>
              <option value="Lucknow">Lucknow</option>
              <option value="Mau">Mau</option>
              <option value="New Delhi">New Delhi</option>
              <option value="Raibareli">Raibareli</option>
              <option value="Sultanpur">Sultanpur</option>
            </select>
          </div>

          <div class="input-box">
            <span class="details">Password</span>
            <input type="text" name="password" placeholder="Enter your password *" >
          </div>
          <div class="input-box">
            <span class="details">Confirm Password</span>
            <input type="text" name="cpassword" placeholder="Confirm your password *" >
          </div>
        </div>

        <div class="button">
          <input type="submit" name="submit" value="Register">
        </div>
        <div class="showdata">
          <a href="select.php"><p>Show Data</p></a>
        </div>
      </form>
      
    </div>
  </div>

</body>
</html>
