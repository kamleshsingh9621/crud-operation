-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Apr 03, 2023 at 11:32 PM
-- Server version: 5.0.45
-- PHP Version: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `crudoperation`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `user`
-- 

CREATE TABLE `user` (
  `id` int(255) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `cpassword` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

-- 
-- Dumping data for table `user`
-- 

INSERT INTO `user` (`id`, `name`, `email`, `phone`, `city`, `password`, `cpassword`) VALUES 
(1, 'kamlesh singh', 'kamleshsingh752581@gmail.com', '+919569458209', 'Lucknow', 'vij123', ''),
(2, 'kamlesh singh', 'rajpatel3434@gmail.com', '+919569458209', 'Lucknow', 'vij123', ''),
(7, 'Subhash Pal', 'subhash123@gmail.com', '1231231234', 'Sultanpur', '1234', ''),
(8, 'Ashish Kumar', 'ashish123@gmail.com', '1231231235', 'Gajipur', '12345', ''),
(9, 'ajay singh', 'ajay234@gmail.com', '9554422548', 'allahabad', '12356', ''),
(10, 'Sandeep Singh', 'sandeep123@gmail.com', '6392106368', 'Kushinagar', '1234', ''),
(11, 'Deepak Singh', 'deepak123@gmail.com', '9554422546', 'Gajipur', '1234', '');
